package com.example.mvvm.model.details

data class DetailsData(val createdat: String,
                       val email: String,
                       val id: Int,
                       val location: String,
                       val name: String,
                       val profilepicture: String)
