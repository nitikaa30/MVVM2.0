package com.example.mvvm.model.login

data class LoginModel(val email: String,
                      val password: String)
